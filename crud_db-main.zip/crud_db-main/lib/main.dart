import 'package:flutter/material.dart';
import 'database_helper.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Notes App',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final dbHelper = DatabaseHelper();
  final titleController = TextEditingController();
  final contentController = TextEditingController();
  List<Note> notes = [];

  @override
  void initState() {
    super.initState();
    loadNotes();
  }

  // Load notes
  void loadNotes() async {
    notes = await dbHelper.getNotes();
    setState(() {});
  }

  // Save note
  void saveNote() {
    if (titleController.text.isNotEmpty && contentController.text.isNotEmpty) {
      dbHelper.saveNote(titleController.text, contentController.text);
      titleController.clear();
      contentController.clear();
      loadNotes();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Notes')),
      body: Column(
        children: [
          // Input fields
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              children: [
                // Title field
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    hintText: 'Enter title',
                    labelText: 'Title',
                  ),
                ),
                const SizedBox(height: 8),
                // Content field
                TextField(
                  controller: contentController,
                  decoration: const InputDecoration(
                    hintText: 'Enter content',
                    labelText: 'Content',
                  ),
                ),
                const SizedBox(height: 8),
                // Save button
                ElevatedButton(
                  onPressed: saveNote,
                  child: const Text('Save Note'),
                ),
              ],
            ),
          ),
          
          // Notes list
          Expanded(
            child: ListView.builder(
              itemCount: notes.length,
              itemBuilder: (context, index) {
                return Card(
                  margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  child: ListTile(
                    title: Text(notes[index].title),
                    subtitle: Text(notes[index].content),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete),
                      onPressed: () {
                        dbHelper.deleteNote(notes[index].id!);
                        loadNotes();
                      },
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
