import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

// Simple Note model with two fields
class Note {
  final int? id;
  final String title;
  final String content;

  Note({this.id, required this.title, required this.content});
}

class DatabaseHelper {
  static Database? _db;

  // Get database
  Future<Database> get db async {
    _db ??= await openDatabase(
      join(await getDatabasesPath(), 'notes.db'),
      onCreate: (db, version) {
        return db.execute(
          'CREATE TABLE notes(id INTEGER PRIMARY KEY, title TEXT, content TEXT)'
        );
      },
      version: 1,
    );
    return _db!;
  }

  // Save note with two fields
  Future<void> saveNote(String title, String content) async {
    final database = await db;
    await database.insert('notes', {
      'title': title,
      'content': content
    });
  }

  // Get all notes
  Future<List<Note>> getNotes() async {
    final database = await db;
    final notes = await database.query('notes');
    
    return notes.map((map) => Note(
      id: map['id'] as int,
      title: map['title'] as String,
      content: map['content'] as String,
    )).toList();
  }

  // Delete note
  Future<void> deleteNote(int id) async {
    final database = await db;
    await database.delete('notes', where: 'id = ?', whereArgs: [id]);
  }
} 