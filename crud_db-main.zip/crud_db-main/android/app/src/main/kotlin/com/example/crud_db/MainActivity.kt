package com.example.crud_db

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
